export interface InfoPagina {
  titulo?: string;
  email?: string;
  nombreCorto?: string;
  paginaAutor?: string;
  facebook?: string;
  twitter?: string;
  instagram?: string;
  equipoTrabajo?: any[];
}
